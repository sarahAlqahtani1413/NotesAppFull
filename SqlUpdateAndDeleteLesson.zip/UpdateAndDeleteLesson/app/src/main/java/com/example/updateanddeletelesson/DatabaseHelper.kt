package com.example.updateanddeletelesson

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context):SQLiteOpenHelper(context,"details.db",null,2) {
    private val sqLiteDatabase: SQLiteDatabase =writableDatabase
    override fun onCreate(db: SQLiteDatabase?) {
        db?.execSQL("create table students (pk INTEGER PRIMARY KEY AUTOINCREMENT, Name text, Location text)")
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db!!.execSQL("DROP TABLE IF EXISTS students")  // This removes the table if a new version is detected
        onCreate(db)    }
    fun saveData(name:String,location:String){
        val contentValue=ContentValues()
        contentValue.put("Name",name)
        contentValue.put("Location",location)
        sqLiteDatabase.insert("students",null,contentValue)
    }
    fun readData():ArrayList<Person>{
        val people= arrayListOf<Person>()
        val cursor:Cursor=sqLiteDatabase.rawQuery("SELECT * FROM students", null)
        if(cursor.count < 1){  // Handle empty table
            println("No Data Found")
        }else{
            while(cursor.moveToNext()){  // Iterate through table and populate people Array List
                val pk = cursor.getInt(0)  // The integer value refers to the column
                val name = cursor.getString(1)
                val location = cursor.getString(2)
                people.add(Person(pk, name, location))
    }
}
        return people
    }
    fun updateData(person: Person) {
        val contentValues = ContentValues()
        contentValues.put("Name", person.name)
        contentValues.put("Location", person.location)
        sqLiteDatabase.update("students", contentValues, "pk = ${person.pk}", null)
    }
    fun deleteData(person: Person){
        sqLiteDatabase.delete("students", "pk = ${person.pk}", null)
    }

}