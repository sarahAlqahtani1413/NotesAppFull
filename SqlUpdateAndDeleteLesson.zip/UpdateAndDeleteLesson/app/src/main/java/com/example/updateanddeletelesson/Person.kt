package com.example.updateanddeletelesson

data class Person(val pk: Int, val name: String, val location: String)

